// Toggle Theme
const toggle = document.querySelector('.theme-toggle');
const body = document.body;

toggle.addEventListener('click', () => {
  body.classList.toggle('light-mode');
});

// Calculator Logic
const result = document.getElementById('result');

function appendNumber(num) {
  result.value += num; // Append numbers directly
}

function appendOperator(operator) {
  if (result.value) {
    // Append display-friendly operators
    if (operator === '/') {
      result.value += '÷';
    } else if (operator === '*') {
      result.value += '×';
    } else {
      result.value += operator; // Append other operators as is
    }
  }
}

function clearDisplay() {
  result.value = '';
}

function deleteDigit() {
  result.value = result.value.slice(0, -1);
}

function calculate() {
  try {
    // Replace display symbols with mathematical operators during evaluation
    const expression = result.value
      .replace(/÷/g, '/')
      .replace(/×/g, '*')
      .replace(/%/g, '/100'); // Handle percentage
    result.value = eval(expression);
  } catch {
    result.value = 'Error';
  }
}
